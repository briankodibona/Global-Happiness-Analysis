# Global Happiness & Economic Indicators

An end-to-end data science project exploring the relationship between happiness scores and economic indicators using machine learning.