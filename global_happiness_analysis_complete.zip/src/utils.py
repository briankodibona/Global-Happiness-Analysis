# Utility functions for data preprocessing and evaluation

def normalize_data(df):
    return (df - df.mean()) / df.std()